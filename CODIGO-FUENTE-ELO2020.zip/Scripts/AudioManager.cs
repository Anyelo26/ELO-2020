﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class AudioManager : MonoBehaviour
{
    public AudioSource effectSource;
    public AudioSource musicSource;

    public AudioClip introMusic;
    public AudioClip menuMusic;
    public AudioClip effectClick;

    public Slider sliderMusic, sliderSFX;

    public void Awake()
    {
        DontDestroyOnLoad(gameObject);
    }
    public void PlayEffect()
    {
        effectSource.PlayOneShot(effectClick);
    }

    public void PlaySong(AudioClip audioClip)
    {
        musicSource.clip = audioClip;
        musicSource.Play();
        
    }
    public void OnMusicVolumenUpdate()
    {
        musicSource.volume = sliderMusic.value;

    }
    public void OnSFXVolumeUpdate()
    {
        effectSource.volume = sliderSFX.value;
    }

}
