﻿using System.Linq;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class QuizDB : MonoBehaviour
{
    [SerializeField] public List<Question> m_questionList=null;
    protected List<Question> m_backup=null;
    private int index;
    private string retroalimentacion;
    private void Awake(){
        m_backup=m_questionList.ToList();
    }
    public Question GetRandom(bool remove=true){
        
        if(m_questionList.Count==0){
            RestoreBackup();
        }
        index= Random.Range(0,m_questionList.Count);
        Debug.Log(index);
        if(!remove){
            return m_questionList[index];
        }
        Question q =m_questionList[index];
        retroalimentacion = q.retroalimentacion;
        //GetRetroalimentacion(retroalimentacion);
        m_questionList.RemoveAt(index);
        return q;
    }
 
    public  string GetRetroalimentacion()
    {
        return retroalimentacion;
    }
    private void RestoreBackup(){
        m_questionList=m_backup.ToList();
    }

}
