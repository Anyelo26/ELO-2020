﻿
[System.Serializable]
public class Option
{
    public string text=null;
    public bool correct=false;
   
}
