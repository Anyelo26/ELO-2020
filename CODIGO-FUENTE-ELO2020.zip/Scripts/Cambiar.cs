﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class Cambiar : MonoBehaviour
{
    public Text SCORE;

    void Start()
    {
        SCORE.text = GameControlerI.score2.ToString();    
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
