﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class ManagerTienda : MonoBehaviour
{
    [Tooltip("Ingresa el Nombre de la escena que le sigue a esta")]
    public string anterior = "SampleScene";

    public void Volver()
    {
        SceneManager.LoadScene(anterior);//este String que se coloca debe de tener 
                                                //el mismo nombre de la escena que se llama   
    }

}
