﻿
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class QuizUI : MonoBehaviour
{
    
    [SerializeField] public Text m_question=null;
    [SerializeField] public List<OptionButton> m_buttonList=null;
    // Start is called before the first frame update
    public void Construct(Question q, Action<OptionButton> callback){
        
        m_question.text =q.text ;
        for (int i = 0; i < m_buttonList.Count; i++)
        {
                m_buttonList[i].Construct(q.options[i], callback);
        }
      
    }
}
