﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Question : MonoBehaviour
{
    public string text=null;
    public List<Option> options=null;
    public string retroalimentacion = null;
    public string getRetroalimentacion()
    {
        return retroalimentacion;
    }
}
