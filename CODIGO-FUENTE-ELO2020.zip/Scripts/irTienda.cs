﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class irTienda : MonoBehaviour
{
    [Tooltip("Ingresa el Nombre de la escena que le sigue a esta")]
    public string siguienteEscena = "SampleScene";
    public void Jugar()
    {
        SceneManager.LoadScene(siguienteEscena);//este String que se coloca debe de tener 
                                                //el mismo nombre de la escena que se llama   
    }

}
