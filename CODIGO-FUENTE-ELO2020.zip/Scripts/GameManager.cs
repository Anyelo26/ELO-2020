﻿using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
[RequireComponent(typeof(AudioSource))]
public class GameManager : MonoBehaviour
{
    [SerializeField]public AudioClip m_correctSound=null;
    [SerializeField]public AudioClip m_incorrectSound=null;
    [SerializeField]public Color m_correctColor= Color.black;
    [SerializeField]public Color m_incorrectColor=Color.black;
    [SerializeField]public float m_waitTime=0.3f;
    [SerializeField]private PlayerName jugador;
    [SerializeField] public Animator animator;
    public GameObject Sonido;
    public QuizDB m_quizDB=null;
    public QuizUI m_quizUI=null;
    public AudioSource m_audioSource=null;
    public GameObject retroalimentacion;
    public Text txt_retro;
    private int num_intentos=0;//es el numero de intentos que tendra el jugador como maximo para poder perder
    public Text Oro_text; //es la cantidad de oro que gana el jugador por respuesta correcta
    private int oro;
    public Text Nombre;

    // private Question aux;//pregunta que esta en el panel para dar retroalimentacion
    public void Awake()
    {
        jugador = GameObject.FindObjectOfType<PlayerName>();
        Nombre.text = jugador.saveName;
    }
    public void Start(){
        m_quizDB= GameObject.FindObjectOfType<QuizDB>();
        m_quizUI= GameObject.FindObjectOfType<QuizUI>();
        //retroalimentacion = GameObject.Find("PopupRetroalimentacion");
        m_audioSource=GetComponent<AudioSource>();
        
        
        NextQuestion();
    }
    public void NextQuestion(){
      //  this.aux = m_quizDB.GetRandom();
        m_quizUI.Construct(m_quizDB.GetRandom(), GiveAnswer);
    }
    private void GiveAnswer(OptionButton op){
        StartCoroutine(GiveAnswerRoutine(op));
    }
    private IEnumerator GiveAnswerRoutine(OptionButton op){
        if(m_audioSource.isPlaying){
            m_audioSource.Stop();
        }
        m_audioSource.clip=op.Option.correct?m_correctSound:m_incorrectSound;
        op.SetColor(op.Option.correct?m_correctColor:m_incorrectColor);
        m_audioSource.Play();
        
        if(op.Option.correct){
            animator.SetTrigger("AnimarG");
            Instantiate(Sonido);
            oro = oro + 30;
            Oro_text.text = "Oro : "+oro.ToString();
            yield return new WaitForSeconds(m_waitTime);
            NextQuestion();
        }
        else{
            txt_retro.text = m_quizDB.GetRetroalimentacion();
            retroalimentacion.SetActive(true);
            num_intentos = num_intentos + 1;
            oro = oro - 15;
            Oro_text.text = "Oro : " + oro.ToString(); ;
            if (num_intentos >= 4)
            {
                GameOver();
            }
        }
    }
    private void GameOver(){
        SceneManager.LoadScene(10);
    }
}
