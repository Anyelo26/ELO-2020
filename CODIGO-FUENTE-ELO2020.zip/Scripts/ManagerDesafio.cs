﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class ManagerDesafio : MonoBehaviour
{
    [Tooltip("Ingresa el Nombre de la escena que le sigue a esta")]
    public string anterior = "SampleScene";
    [Tooltip("Ingresa a la  tienda")]
    public string ir_Tienda = "Tienda";

    public void Awake()
    {
        Destroy(GameObject.Find("AudioManager"));
    }
    public void Volver()
    {
        SceneManager.LoadScene(anterior);//este String que se coloca debe de tener 
                                         //el mismo nombre de la escena que se llama   
    }
    public void irTienda()
    {
        SceneManager.LoadScene(ir_Tienda);
    }
    public void irDesafioNazca()
    {
        SceneManager.LoadScene("Nazca");
    }
    public void irDesafioCaral()
    {
        SceneManager.LoadScene("Caral");
    }
    public void irDesafioTiahuanaco()
    {
        SceneManager.LoadScene("Tiahuanaco");
    }
    public void irDesafioChavin()
    {
        SceneManager.LoadScene("Chavin");
    }
    public void irDesafioMoche()
    {
        SceneManager.LoadScene("Moche");
    }
    public void irDesafioChimu()
    {
        SceneManager.LoadScene("Chimu");
    }

}
