﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Comprar : MonoBehaviour {

    // Start is called before the first frame update
	[System.Serializable] class ComprarItem{
		public Sprite Image;
		public int precio;
		public bool IsPurchased = false;
	}

	[SerializeField] List <ComprarItem> ShopItemList;

	GameObject Item;
	GameObject g;
	Button buyBtn;

    void Start(){
     /*   
        int len = ShopItemList.Count;
        for (int i = 0 ; i < 3 ; i++ ){
        	g.transform.GetChild(0).GetComponent <Image>().sprite = ShopItemList[i].Image;
        	g.transform.GetChild(1).GetChild(0).GetComponent <Text>().text = ShopItemList[i].precio.ToString();
        	buyBtn = g.transform.GetChild(2).GetComponent <Button>();
        	buyBtn.interactable = !ShopItemList[i].IsPurchased;
        	buyBtn.AddEventListener (i, OnShopItemBtnClick);
        }
     */
    }

    void OnShopItemBtnClick(int itemIndex){
    	ShopItemList[itemIndex].IsPurchased = true;
    	
    }

}
