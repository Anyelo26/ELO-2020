﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameControlerI : MonoBehaviour
{
    public int Score = 50;
    public static int score2 = 0;
    void Start()
    {
        
    }
    void Awake()
    {
       // DontDestroyOnLoad(this.gameObject);
    }
        // Update is called once per frame
    void Update()
    {
        
    }
}
