﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class ManagerIntroTiahuanaco : MonoBehaviour
{
    [Tooltip("Ingresa el Nombre de la escena que le antepone a esta")]
    public string anteriorEscena = "SampleScene";
    [Tooltip("Ingresa el Nombre de la escena que le sigue a esta")]
    public string siguienteEscena = "SampleScene";
    public void Volver()
    {
        SceneManager.LoadScene(anteriorEscena);//este String que se coloca debe de tener                                           //el mismo nombre de la escena que se llama   
    }
    public void Saltar()
    {
        SceneManager.LoadScene(siguienteEscena);
    }
}
