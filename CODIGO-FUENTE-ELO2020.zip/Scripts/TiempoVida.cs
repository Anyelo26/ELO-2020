﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TiempoVida : MonoBehaviour
{
    public float tiempodeVida;
    // Start is called before the first frame update
    void Start()
    {
        Destroy(gameObject, tiempodeVida);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
