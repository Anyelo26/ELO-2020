﻿using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine;
using UnityEngine.UI;

public class PlayerName : MonoBehaviour
{
    public string nameOfPlayer;
    public string saveName;

    public Text inputText;
    public Text loadedName;
    //public Text oro;

    // Start is called before the first frame update
    private void Awake()
    {
        // DontDestroyOnLoad(this);
        

    }
    void Start()
    {

        // if (loadedName.text != null)
        // {
        
        nameOfPlayer = PlayerPrefs.GetString("name");
        loadedName.text = nameOfPlayer;
        //}
    }

    // Update is called once per frame
    void Update()
    {
        

        // inputText.no on

    }
    public void SetName()
    {
        saveName = inputText.text;
        PlayerPrefs.SetString("name",saveName);
        DontDestroyOnLoad(this);
    }
}
